echo "enter two numbers"
read a b
diff=$((a-b))
echo "difference is $diff"
