echo "enter two numbers"
read a
read b
sum=$((a+b))


echo "sum is : $sum"
